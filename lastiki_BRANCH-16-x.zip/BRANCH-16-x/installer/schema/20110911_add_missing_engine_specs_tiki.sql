ALTER TABLE tiki_cart_inventory_hold ENGINE = MyISAM;
ALTER TABLE tiki_source_auth ENGINE = MyISAM;
ALTER TABLE tiki_connect ENGINE = MyISAM;
