ALTER TABLE `tiki_sheets` ADD `clonedSheetId` int(8);
ALTER TABLE `tiki_sheet_layout` ADD `clonedSheetId` int(8);
ALTER TABLE `tiki_sheet_values` ADD `clonedSheetId` int(8);