UPDATE `tiki_modules` SET `params` = REPLACE(`params`, '.css', '');
