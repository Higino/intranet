alter table `tiki_wiki_attachments` modify `user` varchar(200) default NULL;
