ALTER TABLE `tiki_score` ADD COLUMN `validObjectIds` text;
