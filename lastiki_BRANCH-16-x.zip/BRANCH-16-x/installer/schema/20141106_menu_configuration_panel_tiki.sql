# xavidp. Option Panels is set with a space in purpose, in order to have it shown in the first position under "Configuration"
update tiki_menu_options set name=' Panels' where name='Admin Home';
update tiki_menu_options set name='Configuration' where name='Admin';