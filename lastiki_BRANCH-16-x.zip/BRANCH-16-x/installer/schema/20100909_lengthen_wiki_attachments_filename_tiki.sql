ALTER TABLE `tiki_wiki_attachments` MODIFY `filename` varchar(255)  default NULL;
