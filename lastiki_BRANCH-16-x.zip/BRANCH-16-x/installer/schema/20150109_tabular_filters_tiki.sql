ALTER TABLE `tiki_tabular_formats` ADD COLUMN `filter_descriptor` TEXT AFTER `format_descriptor`;
