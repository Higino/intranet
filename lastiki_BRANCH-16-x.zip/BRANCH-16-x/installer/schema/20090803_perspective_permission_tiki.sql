
INSERT INTO users_permissions (`permName`, `permDesc`, level, type) VALUES ('tiki_p_perspective_view', 'Can view the perspective', 'basic', 'perspective');

