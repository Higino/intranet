CREATE TABLE IF NOT EXISTS `tiki_workspace_templates` (
	`templateId` INT PRIMARY KEY AUTO_INCREMENT,
	`name` VARCHAR(50),
	`definition` TEXT
) ENGINE=MyISAM;
