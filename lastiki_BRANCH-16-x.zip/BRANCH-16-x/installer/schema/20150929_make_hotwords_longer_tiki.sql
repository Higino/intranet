ALTER TABLE `tiki_hotwords` CHANGE `word` `word` VARCHAR(255);
