ALTER IGNORE TABLE `tiki_file_galleries` ADD `icon_fileId` INT(14)  UNSIGNED  NULL  DEFAULT NULL;
