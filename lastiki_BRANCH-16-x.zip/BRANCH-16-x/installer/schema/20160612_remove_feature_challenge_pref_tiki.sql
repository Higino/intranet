
DELETE FROM tiki_preferences WHERE name='feature_challenge';