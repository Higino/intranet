UPDATE `tiki_menu_options` SET `position` = '39', `type` = 'o' WHERE `url` = 'tiki-timesheet.php';
UPDATE `tiki_menu_options` SET `position` = '38', `type` = 'o' WHERE `url` = 'tiki-edit_report.php';
