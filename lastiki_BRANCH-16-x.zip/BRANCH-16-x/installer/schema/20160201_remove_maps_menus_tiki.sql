DELETE FROM `tiki_menu_options` WHERE `section` = 'feature_maps';
