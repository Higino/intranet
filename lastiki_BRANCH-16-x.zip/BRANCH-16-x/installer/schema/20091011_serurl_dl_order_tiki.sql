UPDATE `tiki_sefurl_regex_out` SET `order` = '10' WHERE `tiki_sefurl_regex_out`.`left` = 'tiki-download_file.php\\?fileId=(\\d+)';
