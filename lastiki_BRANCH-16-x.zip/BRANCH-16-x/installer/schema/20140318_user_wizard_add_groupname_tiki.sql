UPDATE tiki_menu_options SET groupname = 'Registered' WHERE name = 'User Wizard';
