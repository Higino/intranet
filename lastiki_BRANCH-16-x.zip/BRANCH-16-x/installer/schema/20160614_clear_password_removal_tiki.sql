
ALTER TABLE `users_users` DROP `password`;

