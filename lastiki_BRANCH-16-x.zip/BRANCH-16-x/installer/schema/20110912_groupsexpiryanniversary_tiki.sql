ALTER TABLE `users_groups` ADD `anniversary` char(4) default '';
ALTER TABLE `users_groups` ADD `prorateInterval` varchar(255) default '';