ALTER TABLE tiki_rss_items ADD COLUMN categories TEXT;
