ALTER TABLE `tiki_sheet_layout` ADD `parseValues` CHAR( 1 ) NOT NULL DEFAULT 'n';
