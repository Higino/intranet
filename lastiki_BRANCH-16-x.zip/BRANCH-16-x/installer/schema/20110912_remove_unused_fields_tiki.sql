ALTER TABLE tiki_trackers DROP COLUMN showCreated;
ALTER TABLE tiki_trackers DROP COLUMN showStatus;
ALTER TABLE tiki_trackers DROP COLUMN showLastModif;
ALTER TABLE tiki_trackers DROP COLUMN useComments;
ALTER TABLE tiki_trackers DROP COLUMN useAttachments;
ALTER TABLE tiki_trackers DROP COLUMN showAttachments;
ALTER TABLE tiki_trackers DROP COLUMN showComments;
ALTER TABLE tiki_trackers DROP COLUMN orderAttachments;
