# added on 2009-03-01 by luciash: `siteTitle` changed to browsertitle to prevent confusion with sitetitle pref

update `tiki_preferences` set `name`='browsertitle' where `name`='siteTitle';
