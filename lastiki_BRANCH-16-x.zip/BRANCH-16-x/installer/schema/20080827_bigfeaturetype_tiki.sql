
#2008-08-27 bitey
ALTER TABLE tiki_feature MODIFY COLUMN
  `feature_type` varchar(30) NOT NULL default 'feature';

