DELETE FROM  `tiki_quicktags` WHERE  `tiki_quicktags`.`taglabel` =  'Email Address';
