#GillesM
ALTER TABLE `tiki_referer_stats` ADD `lasturl` TEXT DEFAULT NULL AFTER `last` ;
