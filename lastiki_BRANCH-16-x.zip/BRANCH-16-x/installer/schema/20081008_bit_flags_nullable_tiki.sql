ALTER TABLE tiki_pages_translation_bits MODIFY COLUMN flags SET('critical') NULL;
