ALTER TABLE `tiki_extwiki`
	ADD COLUMN `indexname` VARCHAR(20),
	ADD COLUMN `groups` VARCHAR(1024);
