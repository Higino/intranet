UPDATE  `tiki_user_modules` SET `name` = 'Application Menu' WHERE `tiki_user_modules`.`name` = 'mnu_application_menu';
UPDATE  `tiki_modules` SET `name` =  'Application Menu' WHERE `tiki_modules`.`name` = 'mnu_application_menu';
