ALTER TABLE `tiki_newsletters` ADD COLUMN `emptyClipBlocksSend` char(1) default 'n'; 
