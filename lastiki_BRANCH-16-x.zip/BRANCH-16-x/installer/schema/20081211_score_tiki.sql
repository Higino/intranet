#sylvieg
DELETE FROM tiki_menu_options WHERE `url`='tiki-admin_include_score.php';