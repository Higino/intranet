ALTER TABLE `tiki_webmail_contacts_fields` ADD `flagsPublic` CHAR( 1 ) NOT NULL DEFAULT 'n';
