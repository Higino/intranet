ALTER TABLE `tiki_user_monitors` MODIFY COLUMN `target` VARCHAR(25) NOT NULL;
