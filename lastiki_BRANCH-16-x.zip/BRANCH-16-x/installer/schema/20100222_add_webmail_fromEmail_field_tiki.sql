ALTER TABLE `tiki_user_mail_accounts` ADD `fromEmail` VARCHAR( 255 ) NOT NULL DEFAULT '';
