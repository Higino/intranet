ALTER TABLE `tiki_connect` CHANGE `guid` `guid` VARCHAR(64)  NULL  DEFAULT NULL;
