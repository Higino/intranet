alter table `tiki_calendar_items` drop key `fk_calitems_recurrence`;
