DROP TABLE `tiki_searchindex`;
DROP TABLE `tiki_searchsyllable`;
DROP TABLE `tiki_searchwords`;
