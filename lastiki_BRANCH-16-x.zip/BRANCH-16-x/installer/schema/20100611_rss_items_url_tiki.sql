#2010-06-11 pkdille
ALTER TABLE `tiki_rss_items` CHANGE `url` `url` TEXT NOT NULL;
