ALTER TABLE tiki_payment_requests ADD COLUMN detail TEXT;
