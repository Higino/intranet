UPDATE `tiki_menu_options` SET `name`='My Account' WHERE `menuId`=42 AND `name`='MyTiki';
UPDATE `tiki_menu_options` SET `name`='My Account Home' WHERE `menuId`=42 AND `name`='MyTiki Home';
