#jonnyb
ALTER TABLE `tiki_pages` ADD `comments_enabled` CHAR( 1 ) NULL DEFAULT NULL;
