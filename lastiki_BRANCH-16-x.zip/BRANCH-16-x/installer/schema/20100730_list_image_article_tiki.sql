ALTER TABLE `tiki_articles` ADD COLUMN `list_image_x` int(4) default NULL AFTER `image_y`;
