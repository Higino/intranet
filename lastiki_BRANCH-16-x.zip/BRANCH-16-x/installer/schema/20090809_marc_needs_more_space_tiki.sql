ALTER TABLE `tiki_profile_symbols` CHANGE `profile` `profile` VARCHAR( 100 ) NOT NULL ,
CHANGE `object` `object` VARCHAR( 150 ) NOT NULL ;
