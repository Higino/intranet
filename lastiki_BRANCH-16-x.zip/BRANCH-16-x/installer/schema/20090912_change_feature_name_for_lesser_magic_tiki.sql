#pkdille
update tiki_preferences set name='feature_use_minified_scripts' where name='use_minified_scripts';
update tiki_preferences set name='feature_debug_ignore_xdebug' where name='debug_ignore_xdebug';




