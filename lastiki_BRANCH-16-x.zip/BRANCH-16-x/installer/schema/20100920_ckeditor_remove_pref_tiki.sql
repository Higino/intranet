DELETE FROM `tiki_preferences` WHERE `tiki_preferences`.`name` =  'wysiwyg_ckeditor';
