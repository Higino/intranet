
#2008-08-29 lphuberdeau
INSERT INTO users_permissions (`permName`, `permDesc`, level, type) VALUES ('tiki_p_plugin_viewdetail', 'Can view unapproved plugin details', 'editors', 'wiki');
INSERT INTO users_permissions (`permName`, `permDesc`, level, type) VALUES ('tiki_p_plugin_preview', 'Can execute unapproved plugin', 'editors', 'wiki');
INSERT INTO users_permissions (`permName`, `permDesc`, level, type) VALUES ('tiki_p_plugin_approve', 'Can approve plugin execution', 'editors', 'wiki');

