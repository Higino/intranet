alter table `tiki_actionlog` modify column `comment` text default NULL;
