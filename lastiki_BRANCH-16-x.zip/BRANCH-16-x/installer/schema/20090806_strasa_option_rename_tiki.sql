UPDATE `tiki_user_preferences` SET `value` = 'cool.css' WHERE `prefName` = 'theme-option' AND `value` = 'cold.css';
UPDATE `tiki_preferences` SET `value` = 'cool.css' WHERE `name` = 'style_option' AND `value` = 'cold.css';
UPDATE `tiki_preferences` SET `value` = 'cool.css' WHERE `name` = 'site_style_option' AND `value` = 'cold.css';
