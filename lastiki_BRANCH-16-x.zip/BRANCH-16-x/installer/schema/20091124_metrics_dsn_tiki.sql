ALTER TABLE `metrics_metric` ADD COLUMN `metric_dsn` VARCHAR(200) NOT NULL DEFAULT 'local';
