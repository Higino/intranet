update `tiki_preferences` set `value`='/^[ \'\\-_a-zA-Z0-9@\\.]*$/'  where `value`='/^[ \'-_a-zA-Z0-9@\\.]*$/';
