#2008-11-30 gillesm
UPDATE users_permissions SET type = 'menus' WHERE `permName`='tiki_p_edit_menu';
UPDATE users_permissions SET type = 'menus' WHERE `permName`='tiki_p_edit_menu_option';
