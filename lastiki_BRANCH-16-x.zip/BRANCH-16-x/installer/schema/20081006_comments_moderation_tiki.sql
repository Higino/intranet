# 2008-10-06 nyloth
ALTER TABLE tiki_comments ADD COLUMN `approved` char(1) default 'y' NOT NULL;
