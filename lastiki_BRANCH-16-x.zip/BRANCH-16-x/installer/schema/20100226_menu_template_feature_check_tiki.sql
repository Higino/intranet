UPDATE `tiki_menu_options` SET `section` = 'feature_wiki_templates' WHERE `url` = 'tiki-admin_content_templates.php';
