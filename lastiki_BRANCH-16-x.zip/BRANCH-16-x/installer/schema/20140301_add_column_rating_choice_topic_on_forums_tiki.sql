ALTER TABLE `tiki_forums` ADD COLUMN `ui_rating_choice_topic` char(1) DEFAULT NULL AFTER `ui_avatar`;
