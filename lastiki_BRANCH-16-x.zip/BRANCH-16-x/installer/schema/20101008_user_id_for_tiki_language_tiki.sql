ALTER TABLE `tiki_language` ADD COLUMN `userId` int(8) AFTER `changed`;
