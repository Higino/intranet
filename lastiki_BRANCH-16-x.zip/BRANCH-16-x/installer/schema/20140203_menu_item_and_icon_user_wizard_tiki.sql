INSERT INTO `tiki_menu_options` (`menuId`, `type`, `name`, `url`, `position`, `section`, `perm`, `groupname`, `userlevel`) VALUES (42,'o','User Wizard','tiki-wizard_user.php',45,'','','',0);
UPDATE tiki_menu_options SET icon = 'wizard_user48x48' WHERE name = 'User Wizard';
