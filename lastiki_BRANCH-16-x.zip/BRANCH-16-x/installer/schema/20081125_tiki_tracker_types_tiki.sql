#2008-11-25 kerrnel22
ALTER TABLE tiki_tracker_fields CHANGE type type VARCHAR(15) default NULL;

