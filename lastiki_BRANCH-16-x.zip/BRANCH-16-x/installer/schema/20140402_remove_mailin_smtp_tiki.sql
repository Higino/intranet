ALTER TABLE `tiki_mailin_accounts` DROP COLUMN `smtp`, DROP COLUMN `smtpPort`, DROP COLUMN `useAuth`;
