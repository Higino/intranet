UPDATE `tiki_sefurl_regex_out` SET `type` = 'tracker' WHERE `left` = 'tiki-list_trackers.php' AND `right` = 'trackers';
