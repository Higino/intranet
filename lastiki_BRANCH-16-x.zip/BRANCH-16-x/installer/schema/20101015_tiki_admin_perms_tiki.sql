update `users_permissions` set `admin`=NULL where `permName`='tiki_p_admin_importer' or `permName`='tiki_p_admin_toolbars';
