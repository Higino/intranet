ALTER TABLE `tiki_extwiki`
	CHANGE `indexname` `indexname` VARCHAR(255) DEFAULT NULL;
